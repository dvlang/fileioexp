Professor:

The program as compiled in MSVScommunity2017 v 15.2
